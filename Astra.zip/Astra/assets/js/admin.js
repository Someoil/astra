$(function() {
    var mobile__width = 414;


    function opneMenu()
    {
        $('.menu-overlay').remove();
        if (!$('.sidebar--with-menu').hasClass('open')) {
            $('.sidebar--with-menu').addClass('open');
            $('body').append('<div class="menu-overlay"></div>');
        } else {
            $('.sidebar--with-menu').removeClass('open');
        }
    }
    $(document).on('click', '.mobile--header__menu-btn, .menu-overlay', function(){
        opneMenu();
    });
    function isValidEmailAddress(emailAddress) {
        var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
        return pattern.test(emailAddress);
    }
    $('.form--validate').submit(function () {
        var form = $(this);
        var errCount = 0;
        form.find('.input--required').each(function () {
            if ($(this).hasClass('input--checkbox')){
                if (!$(this).prop('checked')) {
                    errCount++;
                }
            } else if ($(this).hasClass('input--text')) {
                if (!$(this).val()) {
                    errCount++;
                    $(this).addClass('input--error');
                } else {
                    $(this).removeClass('input--error');
                }
            } else if ($(this).hasClass('input--email')) {
                form.find('.input--incorrect-email').remove();
                if (!isValidEmailAddress($(this).val())) {
                    errCount++;
                    $(this).addClass('input--error');
                    $(this).after('<div class="input--incorrect-email">incorrect email</div>');
                } else {
                    $(this).removeClass('input--error');
                }
            }
        });
        if (errCount > 0) {
            event.preventDefault();
            return false;
            // setTimeout(function() {
            //     line.removeClass('c')
            // }.bind(this),2000);
        }
    });


    // temp generate

    function getRandomInt(min, max) {
        return Math.floor(Math.random() * (max - min + 1)) + min;
    }

    var startDate = new Date();
    var data = [];

    for (i = 0; i < 50; i++) {
        dd = startDate.setDate(startDate.getDate() + 1);

        data.push({
            "type": 0,
            "value": getRandomInt(800, 900),
            "date": dd
        });
        data.push({
            "type": 1,
            "value": getRandomInt(901, 1500),
            "date": dd
        });
        data.push({
            "type": 2,
            "value": getRandomInt(1501, 2500),
            "date": dd
        });
    }
    var x2Scale_k = 10,
        hh = 450, //svg.attr("height")
        ww = $('.container--admin').width(); //svg.attr("width")

    if (ww > mobile__width) {
        ww = 950;
    }
    var svg = d3.select("svg"),
        margin = {
            top: 20,
            right: 20,
            bottom: 110,
            left: 40
        },
        margin2 = {
            top: 365,
            right: 20,
            bottom: 30,
            left: 40
        };

    if (ww < mobile__width+1) {
        margin.left = 10;
        margin2.left = 10;
        margin.right = 20;
        margin2.right = 20;
        x2Scale_k = 0;
    }
    var width = +ww - margin.left - margin.right,
        height = +hh - margin.top - margin.bottom,
        height2 = +hh - margin2.top - margin2.bottom;


    var parseDate = d3.timeParse("%d.%m.%Y");

    var xScale = d3.scaleTime().range([0, width]),
        x2Scale = d3.scaleTime().range([0, width - x2Scale_k]),
        yScale = d3.scaleLinear().range([height, 0]),
        y2Scale = d3.scaleLinear().range([height2, 0]);

    var xAxis = d3.axisBottom(xScale),
        xAxis2 = d3.axisBottom(x2Scale),
        yAxis = d3.axisLeft(yScale);


    function colors(category) {
        var catColors = ['#9013fe', '#47dab9', '#fff', '#000'];
        return catColors[category.match(/\d+/g)];
    }

    var brush = d3.brushX()
        .extent([
            [0, 0],
            [width + 5, height2]
        ])
        .on("brush end", brushed);

    svg.append("defs").append("clipPath")
        .attr("id", "clip")
        .append("rect")
        .attr("width", width - 5)
        .attr("height", height2);

    if (ww < mobile__width+1) {
        margin.left = 0;
        margin2.left = 0;
    }
    var mainChart = svg.append("g")
        .attr("class", "focus")
        .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

    var bottomTimeline = svg.append("g")
        .attr("id", "bottomTimeline")
        .attr("class", "bottom-brush")
        .attr("transform", "translate(" + margin2.left + "," + margin2.top + ")");

    var bottomChart = bottomTimeline.append("g");
    bottomChart.attr("clip-path", "url(#clip)");


    data.forEach(function(d) {
        d.Date = new Date(d.date);
        if (d.type == 0) {
            d.d0 = +d.value;
            d.d1 = 0;
            d.d2 = 0;
            d.d3 = 0;
        } else if (d.type == 1) {
            d.d1 = +d.value;
            d.d0 = 0;
            d.d2 = 0;
            d.d3 = 0;
        } else {
            d.d2 = +d.value-1;
            d.d3 = 1;
            d.d0 = 0;
            d.d1 = 0;
        }
    })

    var dataset = [];
    data.reduce(function(res, obj) {
        var key = obj.Date;
        if (res[key]) {
            res[key].d0 += obj.d0;
            res[key].d1 += obj.d1;
            res[key].d2 += obj.d2;
            res[key].d3 += obj.d3;
        } else {
            dataset.push(obj);
            res[key] = obj;
        }
        return res;
    }, {});

    data = dataset;

    var stack = d3.stack().keys(["d0", "d1", "d2", "d3"]);
    var series = stack(data);

    var yMax = d3.max(series[series.length - 1], function(d) {
        return d[1];
    });
    var barW = 13;
    if (ww < mobile__width+1) {
        barW = 5;
    }
    xScale.domain(d3.extent(data, function(d) {
        return d.Date;
    }));
    yScale.domain([0, yMax]);
    x2Scale.domain(xScale.domain());
    y2Scale.domain(yScale.domain());


    var div = d3.select("body").append("div")
        .attr("class", "tooltip")
        .style("opacity", 0)


    var groups = mainChart.selectAll("g")
        .data(series)
        .enter()
        .append("g");

    groups.selectAll("rect")
        .data(function(d) {
            return d;
        })
        .enter().append("rect")
        .attr("id", "bar")
        .attr("fill", function(d) {
            return colors(d3.select(this.parentNode).datum().key)
        })
        .attr('stroke', 'black')
        .attr("stroke-width", function(d) {
           //  console.log(d3.select(this.parentNode).datum().key);
            if (d3.select(this.parentNode).datum().key=='d3') {
                return '2px';
            } else {
                return '0';
            }
        })
        .attr("x", function(d) {
            return xScale(d.data.Date)
        })
        .attr("y", function(d) {
            return yScale(d[1])
        })
        .attr("width", barW)
        .attr("height", function(d) {
            return yScale(d[0]) - yScale(d[1])
        });

    var bottomGroups = bottomChart.selectAll("g")
        .data(series)
        .enter()
        .append("g");

    bottomGroups.selectAll("rect")
        .data(function(d) {
            return d;
        })
        .enter().append("rect")
        .attr("fill", function(d) {
            return colors(d3.select(this.parentNode).datum().key)
        })
        .attr("x", function(d) {
            return x2Scale(d.data.Date)
        })
        .attr("y", function(d) {
            return y2Scale(d[1])
        })
        .attr("width", Math.floor(barW ))
        .attr("height", function(d) {
            return y2Scale(d[0]) - y2Scale(d[1])
        })

    mainChart.append("g")
        .attr("id", "main-timeline")
        .attr("class", "axis axis--xScale")
        .attr("transform", "translate(0," + height + ")")
        .call(xAxis)

    if (ww > mobile__width) {
        mainChart.append("g")
            .attr("class", "axis axis--yScale")
            .call(yAxis)
    }


    bottomTimeline.append("g")
        .attr("id", "brush-timeline")
        .attr("class", "axis axis--x2Scale")
        .attr("transform", "translate(0," + height2 + ")")

    bottomChart.append("g")
        .attr("class", "brush")
        .call(brush)
        .call(brush.move, xScale.range())

    function brushed() {
        var s = d3.event.selection || x2Scale.range();
        xScale.domain(s.map(x2Scale.invert, x2Scale));
        mainChart.select(".axis--xScale").call(xAxis);
        mainChart.selectAll("#bar")
            .attr("x", function(d) {
                return xScale(d.data.Date)
            })
    }

//
})
