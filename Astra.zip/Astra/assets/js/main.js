$(function() {
    AstraGOptions = {
        gotoplan: '',
        plans: {
            free: {
                title: 'Free plan',
                period: '1 year contract',
                descr: 'If Ether mining is not possible anymore,<br>' +
                    'the contract will be switched to another <br>' +
                    'algorithm on a best-effort basis. ',
                profit: {
                    hour: 'free hour',
                    month: 'free month ',
                },
                type: 'just test it',
                type_use: 'just test it',
                price: 'Free',
                block: '--free',
                limit: '1 year contract',
                payments: 'just for $12',
            },
            astra: {
                title: 'Astra plan',
                period: '10 years contract',
                descr: 'This is the classic version <br>' +
                    'where you mine continuously <br>' +
                    'for the term.',
                profit: {
                    hour: 'astra h',
                    month: 'astra m',
                },
                type: 'payment daily',
                type_use: '',
                price: '$5,000.00 or 1.00211 btc',
                block: '--astra',
                payments: 'Payments daily',
                limit: '10 years contract',
            }
        },
        currency: {
            btc: 6639,
            ths: 0.14
        },
        k: {
            revenue: {
                week: 7,
                month: 30,
                year: 365,
                year_3: 1095,
                year_7: 2555,
            },
            maint: {
                week: 5,
                month: 25,
                year: 320,
                year_3: 999,
                year_7: 2365
            },
        },
        form_buy:  '#form--buy-id',
    };
    function updateInPricingContract(v)
    {

        var r = $('.dropdown--period-revenue option:selected').val();
        var t = $('.dropdown--period-revenue option:selected').html();
        $('.input--dropdown-period-maint').val(r);
        $('.dropdown-period-maint').html(t);
        // var m = $('.dropdown--period-maint option:selected').val();

        var nprice = AstraGOptions.k.revenue[r] * v * AstraGOptions.currency.ths;
        var nbtc = Math.round((nprice / AstraGOptions.currency.btc)*1000)/1000;

        $('.dropdown--value-revenue .price').html(Math.round(nprice));
        $('.dropdown--value-revenue .in-btc').html(nbtc);

        nprice = AstraGOptions.k.maint[r] * v * AstraGOptions.currency.ths;
        nbtc = Math.round((nprice / AstraGOptions.currency.btc)*1000)/1000;

        $('.dropdown--value-maint .price').html(Math.round(nprice));
        $('.dropdown--value-maint .in-btc').html(nbtc);

    }

    function getCustomRangeValue(v)
    {
        var val = 0;

        if (v > 0 && v < 100) {
            val = v;
        } else if (v > 99 && v < 120) {
            val = 100 + (v - 100) * 5;
        } else if (v > 119 && v < 200) {
            val = 200 + (v - 120) * 10;
        } else if (v > 199) {
            val = 1000 + (v - 200) * 100;
        }
        // console.log('in:'+v+'out:'+val);
        return val;

    }
    if (window.matchMedia("(min-width: 415px)").matches) {
        new fullpage('.container--full-page', {
            //options here
            licenseKey: 'OPEN-SOURCE-GPLV3-LICENSE',
            verticalCentered: true,
            anchors: ['about', 'pricing', 'geography', 'reserve-fund', 'ipo', 'advantages', 'contactus', 'login'],
            menu: '.main-menu'
        });
        fullpage_api.setAllowScrolling(true);
        $(document).on('mousemove', function (e) {
            $('.container-figure').css({
                left: -e.pageX / 10 + 100,
                top: -e.pageY / 10 + 100
            });
        });
    } else {
        $(document).on('click', '.section--advantages__advantages__item', function(){
            if ($(this).hasClass('open')) {
                $(this).removeClass('open');
            } else {
                $('.section--advantages__advantages__item').removeClass('open');
                $(this).addClass('open');
            }
        });
        $(document).on('click', '.block--reserve__item', function(){
            if ($(this).hasClass('open')) {
                $(this).removeClass('open');
            } else {
                $('.block--reserve__item').removeClass('open');
                $(this).addClass('open');
            }
        });

        $('.block--power-offers').slick({
            arrows: false,
            slidesToShow: 1,
            slidesToScroll: 1,
            dots: false,
            infinite: false,
            adaptiveHeight: false,
            variableWidth: false
        });


        $('.section--about').height(window.innerHeight);
        var vh = $('.section--about .section--about__inner').height();
        $('.mobile-figure').css('top', vh + 70);
        $('.mobile-figure').css('height', window.innerHeight - 240);

        $(window).scroll(function () {
            var top = window.innerHeight - 61;
            var scrollTop = $(window).scrollTop();
            if (scrollTop > top) {
                if (!$('body').hasClass('b-mobile')) $('body').addClass('b-mobile');
            } else {
                $('body').removeClass('b-mobile');
            }
        });

        function opneMenu()
        {
            $('.menu-overlay').remove();
            if (!$('.sidebar--with-menu').hasClass('open')) {
                $('.sidebar--with-menu').addClass('open');
                $('body').append('<div class="menu-overlay"></div>');
            } else {
                $('.sidebar--with-menu').removeClass('open');
            }
        }

        $(document).on('click', '.mobile--header__menu-btn, .menu-overlay', function(){
            opneMenu();
        });
        $(document).on('click', '.main-menu__item a', function(){
            event.preventDefault();
           var b = $(this).attr('data-block-scroll');
            console.log(b);
           var t = $('.section--'+b).offset().top;

           if (b !== 'about') {
               t -= 60;
           }
            window.scrollTo(0, t);
            opneMenu();

        });
    }

    $('select').customSelect({});

    function isValidEmailAddress(emailAddress) {
        var pattern = new RegExp(/^(("[\w-\s]+")|([\w-]+(?:\.[\w-]+)*)|("[\w-\s]+")([\w-]+(?:\.[\w-]+)*))(@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$)|(@\[?((25[0-5]\.|2[0-4][0-9]\.|1[0-9]{2}\.|[0-9]{1,2}\.))((25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\.){2}(25[0-5]|2[0-4][0-9]|1[0-9]{2}|[0-9]{1,2})\]?$)/i);
        return pattern.test(emailAddress);
    }
    $('.form--validate').submit(function () {
        var form = $(this);
        var errCount = 0;
        form.find('.input--required').each(function () {
            if ($(this).hasClass('input--checkbox')){
                if (!$(this).prop('checked')) {
                    errCount++;
                }
            } else if ($(this).hasClass('input--text')) {
                if (!$(this).val()) {
                    errCount++;
                    $(this).addClass('input--error');
                } else {
                    $(this).removeClass('input--error');
                }
            } else if ($(this).hasClass('input--email')) {
                form.find('.input--incorrect-email').remove();
                if (!isValidEmailAddress($(this).val())) {
                    errCount++;
                    $(this).addClass('input--error');
                    $(this).after('<div class="input--incorrect-email">incorrect email</div>');
                } else {
                    $(this).removeClass('input--error');
                }
            }
        });
        if (errCount > 0) {
            event.preventDefault();
            return false;
            // setTimeout(function() {
            //     line.removeClass('c')
            // }.bind(this),2000);
        }
    });

    $(document).on('change', '.dropdown--period', function(){
        var v = $('.range--pricing-contract').html();
        updateInPricingContract(v)
    });


    function updateOfferRange(v)
    {
        var customValue = getCustomRangeValue(v);
        $('.range--astra-offer-value').html(customValue).addClass('l-ths');
    }
    $('.range-power-offer')
        .rangeslider({
            polyfill: false,
            onInit: function() {updateOfferRange(this.value)},
        })
        .on('input', function() {
            updateOfferRange(this.value)
        });

    function checkRangeFree(e){
        var p = $(e).parents('.container--range-control');
        if (e.value > 0) {
            $(p).find('.range--left-free').addClass('range--free');
        } else {
            $(p).find('.range--left-free').removeClass('range--free');
        }
    }

    $('.range-mining-contract')
        .rangeslider({
            polyfill: false,
            onInit: function() {
                checkRangeFree(this);
                $('.range-mining-contract__value').html(this.value);
            },
        })
        .on('input', function() {
            checkRangeFree(this);
            updateInPricingContract(this.value);
            var customValue = getCustomRangeValue(this.value);

            if (customValue > 0 ) {
                $('.range-mining-contract__value.range--pricing-contract').html(customValue)
                    .removeClass('l-ghs')
                    .addClass('l-ths');
            } else {
                $('.range-mining-contract__value.range--pricing-contract')
                    .html(10)
                    .addClass('l-ghs')
                    .removeClass('l-ths');
            }
        });



    function updateFormBuyForPlanByValue(v)
    {
        var o = v > 0 ? AstraGOptions.plans['astra'] : AstraGOptions.plans['free'];
        var f = AstraGOptions.form_buy;

        $(f).find('.range--buy-contract__contract-variant').html(o.title);
        $(f).find('.range--buy-contract__range-control-period').html(o.period);
        $(f).find('.range--buy-contract__additional__descr').html(o.descr);

        $(f).find('.range--buy-contract__stats__hour').html(o.profit.hour);
        $(f).find('.range--buy-contract__stats__month').html(o.profit.month);

        $(f).find('.range--buy-contract__summary-payments').html(o.payments);

        $(f).find('.range--buy-contract__summary-limit').html(o.limit);
        $(f).find('.range--buy-contract__summary-currency').html(AstraGOptions.currency.btc);
        $(f).find('.range--buy-contract__summary-price').html(o.price);


        $(f).find('.range--buy-contract__use').html(o.type_use);
        $(f).find('.range--buy-contract__summary-btn').hide();
        $(f).find('.range--buy-contract__summary-btn'+o.block).show();



        if (v > 0 ) {
            $('.form--buy .input--power').val(v*1000);
            $(f).find('.range--buy-contract__summary-power').html(v)
                .removeClass('l-ghs')
                .addClass('l-ths');
            $(f).find('.range--buy-contract-value').html(v)
                .removeClass('l-ghs')
                .addClass('l-ths');
            $(f).find('.range--buy-contract__summary-input-power').val(v*1000);
        } else {
            $('.form--buy .input--power').val(10);
            $(f).find('.range--buy-contract-value')
                .html(10)
                .addClass('l-ghs')
                .removeClass('l-ths');
            $(f).find('.range--buy-contract__summary-input-power').val(10);
            $(f).find('.range--buy-contract__summary-power').html(10)
                .addClass('l-ghs')
                .removeClass('l-ths');
        }

        // options
        if (v > 99) {
            $('.item--support').addClass('active');
        } else {
            $('.item--support').removeClass('active');
        }
        if (v > 199) {
            $('.item--power').addClass('active');
        } else {
            $('.item--power').removeClass('active');
        }
        if (v > 999) {
            $('.item--manager').addClass('active');
        } else {
            $('.item--manager').removeClass('active');
        }
        if (v > 1999 ) {
            $('.item--exclusive').addClass('active');
        } else  {
            $('.item--exclusive').removeClass('active');
        }
    }
    $('.range--buy-contract')
        .rangeslider({
            polyfill: false,
            onInit: function() {

                },
        })
        .on('input', function() {

            checkRangeFree(this);
            var p = $(this).parents('.container--range-control');
            var customValue = getCustomRangeValue(this.value);
            updateFormBuyForPlanByValue(customValue);

            if (window.matchMedia("(min-width: 415px)").matches) {
                var l = $(p).find('.rangeslider__handle').css('left');
                $(p).find('.range--buy-contract-additional').css('margin-left', l);
                $('.range-control-period').css('margin-left', l);
            }


        });

    $(document).on('click', '.action--login', function(){
        var f = $(this).data('form');

        $('.container--form').removeClass('active');
        $('.container--form-' + f).addClass('active');
    });

    function updateFormuyForPlan(v)
    {
        var f = AstraGOptions.form_buy;
        var o = AstraGOptions.plans[v];
        $(f).find('.contract-variant').html(o.title);
    }

    function openBuyForm(v)
    {
        $('.range--buy-contract').val(v).change();
        $.fancybox.open({
            src  : AstraGOptions.form_buy,
            type : 'inline',
        });
    }

    $(document).on('click', '.open--get-mining-offer-contract', function() {
        //updateFormuyForPlan('free');
        var v = parseInt($('.range-power-offer').val());
        openBuyForm(v);
    });
    $(document).on('click', '.open--get-mining-contract', function() {
        //updateFormuyForPlan('free');
        var v = parseInt($('.range-mining-contract').val());
        openBuyForm(v);
    });
    $(document).on('click', '.open--get-free-contract', function() {
        //updateFormuyForPlan('free');
        openBuyForm(0);
    });
    $(document).on('click', '.open--get-astra-contract', function() {
       // updateFormuyForPlan('astra');
        openBuyForm(100);
    });




});
